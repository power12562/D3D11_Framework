﻿#include "StartApp.h"
#include <GameObject\Base\CameraObject.h>

StartApp::StartApp()
{
    this->windowName = L"StartApp";
}

StartApp::~StartApp()
{

}
