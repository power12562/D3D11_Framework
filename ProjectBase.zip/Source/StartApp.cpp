﻿#include "StartApp.h"

StartApp::StartApp()
{
    this->windowName = L"StartApp";
    //this->SetBorderlessWindowed();
    //this->SetOptimalScreenSize();
}

StartApp::~StartApp()
{

}
