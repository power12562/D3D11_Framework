#include "StartScene.h"
#include <framework.h>

StartScene::StartScene()
{
	UseImGUI = true;

	auto mainCamera = NewGameObject<CameraObject>(L"MainCamera");
	mainCamera->SetMainCamera();
	mainCamera->transform.position = Vector3(0, 0, -5);
	mainCamera->AddComponent<CameraMoveHelper>();

	auto cube = NewGameObject<CubeObject>(L"Cube");
}

StartScene::~StartScene()
{
}

void StartScene::ImGUIRender()
{
	ImGui::Begin("Hierarchy");
	ObjectList objectList = sceneManager.GetObjectList();
	for (auto& item : objectList)
	{
		ImGui::Text(item->GetNameToString().c_str());
		ImGui::EditTransform(item);
		ImGui::Text("");
	}
	ImGui::Text("Light");
	ImGui::SliderFloat3("Light Dir", reinterpret_cast<float*>(&PBRDirectionalLight::cb_light.LightDir), -1.f, 1.f);
	ImGui::ColorEdit3("Light Diffuse", &PBRDirectionalLight::cb_light.LightColor);
	ImGui::ColorEdit3("Light Ambient", &PBRDirectionalLight::cb_light.LightAmbient);
	ImGui::DragFloat("Light Intensity", &PBRDirectionalLight::cb_light.LightIntensity, 1.0f, 0.f, 100.f);
	ImGui::Text("");
	ImGui::End();

}
