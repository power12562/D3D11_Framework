﻿#include "StartApp.h"

StartApp::StartApp()
{
    this->windowName = L"StartApp";
   

}

StartApp::~StartApp()
{
}

void StartApp::Update()
{
}

void StartApp::Render()
{
}
