#pragma once
#include <Framework/D3D11_GameApp.h>

class StartApp : public D3D11_GameApp
{
public:
	StartApp();
	~StartApp();
};