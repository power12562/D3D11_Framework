#pragma once
#include <Framework/WinGameApp.h>

class StartApp : public WinGameApp
{
public:
	StartApp();
	~StartApp();

protected:
	virtual void Start()  override;
	virtual void Update() override;
	virtual void Render() override;

};