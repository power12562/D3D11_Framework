#pragma once
#include <Framework/D3D11_GameApp.h>
#include <Framework/SceneManager.h>

class StartApp : public D3D11_GameApp
{
public:
	StartApp();
	~StartApp();
};